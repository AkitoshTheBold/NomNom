/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package nomnom;

/**
 *
 * @author Admin
 */
public class SaveData implements java.io.Serializable {
    private static final long serialVersionUID = 1l;
    
    public int pScore = 0;
}
